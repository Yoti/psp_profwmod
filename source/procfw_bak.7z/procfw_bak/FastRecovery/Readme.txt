FastRecovery: Boot the 635PRO faster once installed

Techinally it's a rebootex loader.
