Exception: A optional plugins that can catch most of exceptions and write to ms0:/exception.txt.
Enable it in seplugins and run your application or game or pops.

Note: Not all exceptions(crash) can be caught.