pspbtcnf_editor: An script that add modules from pspbtcnf
