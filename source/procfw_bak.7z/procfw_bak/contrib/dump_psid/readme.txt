﻿Run eboot.pbp, after exit, send ms0:/PSID.txt to me
运行eboot.pbp，退出后将ms0:/PSID.txt发给我
