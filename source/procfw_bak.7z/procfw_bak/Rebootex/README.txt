The source of Rebootex goes here.

Rebootex: Initalize the default configure and load the rebootex.bin into kernel. And reboot the HEN into CFW.
