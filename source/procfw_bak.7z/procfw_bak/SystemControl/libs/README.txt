The exported library for SystemControl goes here.
