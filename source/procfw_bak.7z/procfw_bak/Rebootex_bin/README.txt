The source of Rebootex.bin goes here.
