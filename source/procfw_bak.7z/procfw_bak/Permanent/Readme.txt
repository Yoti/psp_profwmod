Permanent: Permanent patch for 6.20 PRO
