#ifndef PPATCH_CONFIG_H
#define PPATCH_CONFIG_H

#define VSHMAIN "flash0:/vsh/module/vshmain.prx"
#define VSHORIG "flash0:/vsh/module/vshorig.prx"
#define VSHTEMP "flash0:/vsh/module/vshtemp.prx"
#define PRXPATH "hen.prx"
#define MODPATH "kmod.prx"

#endif
