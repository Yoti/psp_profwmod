The source of Galaxy goes here.

Galaxy: the Mastermind forced np9660 to accept plain ISO
