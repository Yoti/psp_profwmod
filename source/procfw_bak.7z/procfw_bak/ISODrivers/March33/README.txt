the source of March33(reversed) goes here

5.00                      6.20                     6.35					6.60
sceUmd_2B9A7E2E  ->       sceUmd_F60013F8    ->   sceUmd_7E185F98	-> sceUmd_982272FE
sceUmd_79EF9E56  ->       sceUmd_9F53CFA1    ->   sceUmd_47B447E5	-> sceUmd_BA3D2A5F
sceUmd_E9586C03  ->       sceUmd_E70E8FFB    ->   sceUmd_8213F674	-> sceUmd_A9B5B972
sceUmd_51C04466  ->       sceUmd_74145046    ->   sceUmd_FAAA2DC6	-> sceUmd_98AFBD10
sceUmd_F7C6E4D9  ->       sceUmd_6592E954    ->   sceUmd_F0E95430	-> sceUmd_8DCFBA06
sceUmd_10542751  ->       sceUmd_004F4BE5    ->   sceUmd_24E838BA	-> sceUmd_040A7090
sceUmd_25B21837  ->       sceUmd_1BA5BAFB    ->   sceUmd_749B5538	-> sceUmd_666580EA
sceUmd_30DCD985  ->       sceUmd_B1641203    ->   sceUmd_B1E889EB	-> sceUmd_4F017CDE
sceUmd_3DD57F37  ->       sceUmd_7E6182C7    ->   sceUmd_3F826E9B	-> sceUmd_07E98AF8
sceUmd_6404E484  ->       sceUmd_5083C012    ->   sceUmd_58708431	-> sceUmd_5EBB491F
sceUmd_0743D00D  ->       sceUmd_51C95C02    ->   sceUmd_6E350FE4	-> sceUmd_598EC4DC
sceUmd_36FF82F3  ->       sceUmd_70D9B731    ->   sceUmd_E34F613F	-> sceUmd_0B14CE61
sceUmd_0F2D9908  ->       sceUmd_2D5CB292    ->   sceUmd_7E45DF26	-> sceUmd_B7BF4C31
sceUmd_085E7AFF  ->       sceUmd_B826BD59    ->   sceUmd_507AB2B8	-> sceUmd_6EDF57F1
sceUmd_F8E0D303  ->       sceUmd_35B13E16    ->   sceUmd_145DBD8C	-> sceUmd_18E225C8

sceUmdMan_driver_B9B02322 -> sceUmdMan_driver_6A1FB0DD -> sceUmdMan_driver_E52119E7	-> sceUmdMan_driver_34375DB0
sceUmdMan_driver_31699C86 -> sceUmdMan_driver_7DF4C4DA -> sceUmdMan_driver_7AD43944	-> sceUmdMan_driver_A7536109
sceUmdMan_driver_988597A2 -> sceUmdMan_driver_F7A0D0D9 -> sceUmdMan_driver_42D993AC	-> sceUmdMan_driver_65E2B3E0
sceUmdMan_driver_63B69CE1 -> sceUmdMan_driver_4FFAB8DA -> sceUmdMan_driver_26C75616	-> sceUmdMan_driver_3C8C523D
sceUmdMan_driver_B54D5BE8 -> sceUmdMan_driver_D37B6422 -> sceUmdMan_driver_454E1B06	-> sceUmdMan_driver_80D31D5D

sceUmd9660_driver_7BF6DE7C -> sceUmd9660_driver_63342C0F -> sceUmd9660_driver_385336B5 -> sceUmd9660_driver_887C3193
sceUmd9660_driver_B15139FE -> sceUmd9660_driver_6FFFEE54 -> sceUmd9660_driver_1D89BD8F -> sceUmd9660_driver_C0933C16
sceUmd9660_driver_DF36DCB6 -> sceUmd9660_driver_7CB291E3 -> sceUmd9660_driver_94ACF219 -> sceUmd9660_driver_7EB57F56

Patch offsets for sceIsofs_Driver:
5.00      6.20      6.35      6.60
404C      4020      4020      3FEC
4084      4058      4058      4024
4138      410C      410C      40D8
4314      42E8      42E8      42B4

