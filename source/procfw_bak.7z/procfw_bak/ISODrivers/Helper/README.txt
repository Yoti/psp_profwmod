Here is the source of an ISO drivers test plugins.
