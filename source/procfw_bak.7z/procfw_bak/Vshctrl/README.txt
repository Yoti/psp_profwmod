The source of VshCtrl goes here.

VshCtrl contains:
All VSH related patches,
ISO file display in VSH,
Launching satalite or recovery
