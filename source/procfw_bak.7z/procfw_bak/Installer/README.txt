The source of 635PRO installer goes here

Installer: install nessary CFW files to 6.35 OFW. It should be run under 635HEN.
